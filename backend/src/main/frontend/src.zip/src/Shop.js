import React from "react";
import SearchBar from "./component/SearchBar";
import ProductList from "./component/ProductList";
import Header from "./component/Header";
import { PointsProvider } from "./PointsContext";
import ShopReask from "./ShopReask";
import ProductItem from "./component/ProductItem";
import "./styles/Shop.css";

const Shop = () => {
  const product = { name: "상품1", price: 1000, image: "상품이미지.jpg" };
  return (
    <div className="Shop">
      <Header />
      <SearchBar />
      <ProductList />
      <PointsProvider />
      <ShopReask />
      <ProductItem product={product} />
      <header className="header">
        <img src="시니어스쇼핑몰.png" alt="로고" className="로고" />
        <div className="header-text">
          시니어스 쇼핑몰
          <br />
          보유 포인트: 0P
        </div>
      </header>
      <h1>쇼핑몰</h1>
    </div>
  );
};

export default Shop;
