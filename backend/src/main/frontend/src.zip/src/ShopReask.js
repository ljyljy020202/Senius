import React from "react";
import "./styles/ShopReask.css";
import { products } from "./component/ProductList";
import Header from "./component/Header";
import { PointsProvider } from "./PointsContext";
import ProductItem from "./component/ProductItem";

function ShopReask() {
  return (
    <PointsProvider>
      <div className="ShopReask">
        <Header />
        {products.map((product) => (
          <ProductItem key={product.id} product={product} />
        ))}
      </div>
    </PointsProvider>
  );
}

export default ShopReask;
