import React from "react";
import "../styles/SearchBar.css";
import RG from "../assets/검색창아이콘.png";

const SearchBar = () => {
  return (
    <div className="search-bar">
      <input type="text" placeholder="검색해주세요" className="search-input" />
      <button className="search-button">
        <img src={RG} alt="search" />
      </button>
    </div>
  );
};

export default SearchBar;
