import React, { useContext } from "react";
import "../styles/ProductItem.css";
import { PointsContext } from "../PointsContext";

function ProductItem({ product }) {
  const { points, setPoints } = useContext(PointsContext);
  const giftConPrice = product.price;
  const remainingPoints = points - giftConPrice;

  const handlePurchase = () => {
    if (remainingPoints >= 0) {
      setPoints(remainingPoints);
      alert("구매가 완료되었습니다!");
    } else {
      alert("포인트가 부족합니다.");
    }
  };

  return (
    <div className="product">
      <h2 className="product-title">{product.name}</h2>
      <img src={product.image} alt={product.name} className="product-image" />
      <br />
      <button className="gift-button">현재 포인트 {points}</button>
      <br />
      <button className="gift-button">기프티콘(CU) {giftConPrice}</button>
      <br />
      <button className="gift-button">남는 포인트 {remainingPoints}</button>
      <p>정말로 구매하시겠습니까?</p>
      <button className="buy-button" onClick={handlePurchase}>
        구매하기
      </button>
    </div>
  );
}

export default ProductItem;
