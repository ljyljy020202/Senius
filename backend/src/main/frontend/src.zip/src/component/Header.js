import React, { useContext } from "react";
import "../styles/Header.css";
import Logo from "../assets/시니어스쇼핑몰.png";
import { PointsContext } from "../PointsContext";

const Header = () => {
  const { points } = useContext(PointsContext);

  return (
    <header className="header">
      <img src={Logo} alt="로고" className="logo" />
      <div className="header-text">시니어스 쇼핑몰</div>
      <br></br>
      <div className="earnedPoint">보유 포인트: {points}P</div>
    </header>
  );
};

export default Header;
