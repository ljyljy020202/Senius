import React from "react";
import "./styles/App.css";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Switch,
} from "react-router-dom";
import { PointsProvider } from "./PointsContext";
import Header from "./component/Header";
import Shop from "./Shop";
import ShopBuy from "./ShopBuy";
import ShopReask from "./ShopReask";
import Barcode from "./Barcode";
import ProductItem from "./component/ProductItem";
import { products } from "./component/ProductList";

function App() {
  return (
    <PointsProvider>
      <Router>
        <Routes>
          <Route path="/shop" element={<Shop />} />
          <Route path="/shopbuy" element={<ShopBuy />}></Route>
          <Route path="/shopreask" element={<ShopReask />}></Route>
          <Route path="/barcode" element={<Barcode />}></Route>
          {/* 다른 라우트 추가 가능 */}
        </Routes>
      </Router>
    </PointsProvider>
  );
}

export default App;
