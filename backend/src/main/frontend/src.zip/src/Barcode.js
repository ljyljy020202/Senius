import React from "react";
import "../src/styles/Barcode.css";

const ProductInfo = () => {
  const handleShare = () => {
    alert("성공적으로 공유되었습니다!");
  };

  return (
    <div className="product-info">
      <p>
        구매한 상품은 내 정보 <br></br>→ 구매내역 에서도 확인 가능합니다
      </p>
      <button className="product-button">비타 500</button>
      <div className="product-image-container">
        <img src="path-to-image.png" alt="비타 500" className="product-image" />
        <button className="share-button" onClick={handleShare}>
          공유하기
        </button>
      </div>
    </div>
  );
};

//비타오백으로 우선적으로 만들어 두긴 했는데 변수값 가져와서 변경해야할 거 같음 그 전에 한 개씩 뜨게 어떻게 하는지 ㅠㅠ//
export default ProductInfo;
